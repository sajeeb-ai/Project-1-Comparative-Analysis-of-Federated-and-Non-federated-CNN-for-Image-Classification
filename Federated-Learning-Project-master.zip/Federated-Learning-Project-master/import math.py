import math

a=[3,3]
b=[2,1]

c = abs(a[0]-b[0])
print(c)